package org.akhq.security.mapper;

import io.micronaut.context.annotation.Replaces;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.annotation.NonNull;
import io.micronaut.core.annotation.Nullable;
import io.micronaut.core.util.StringUtils;
import io.micronaut.security.authentication.AuthenticationFailed;
import io.micronaut.security.authentication.AuthenticationResponse;
import io.micronaut.security.config.AuthenticationModeConfiguration;
import io.micronaut.security.oauth2.configuration.OpenIdAdditionalClaimsConfiguration;
import io.micronaut.security.oauth2.endpoint.authorization.state.State;
import io.micronaut.security.oauth2.endpoint.token.response.DefaultOpenIdAuthenticationMapper;
import io.micronaut.security.oauth2.endpoint.token.response.OpenIdClaims;
import io.micronaut.security.oauth2.endpoint.token.response.OpenIdTokenResponse;
import io.micronaut.security.rules.SecurityRule;
import io.reactivex.Flowable;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.akhq.configs.security.Oidc;
import org.akhq.models.security.ClaimProvider;
import org.akhq.models.security.ClaimProviderType;
import org.akhq.models.security.ClaimRequest;
import org.akhq.models.security.ClaimResponse;
import org.reactivestreams.Publisher;

import java.util.*;
import java.util.stream.Collectors;

/**
 * An OpenID user details mapper that is configurable in the akhq config.
 * <p>
 * It will read a username and roles from the OpenID claims and translate them to akhq roles.
 */
@Singleton
@Replaces(DefaultOpenIdAuthenticationMapper.class)
@Requires(property = "akhq.security.oidc.enabled", value = StringUtils.TRUE)
public class OidcUserDetailsMapper extends DefaultOpenIdAuthenticationMapper {
    @Inject
    private Oidc oidc;

    @Inject
    private ClaimProvider claimProvider;

    public OidcUserDetailsMapper(OpenIdAdditionalClaimsConfiguration openIdAdditionalClaimsConfiguration, AuthenticationModeConfiguration authenticationModeConfiguration) {
        super(openIdAdditionalClaimsConfiguration, authenticationModeConfiguration);
    }

    @NonNull
    @Override
    public Publisher<AuthenticationResponse> createAuthenticationResponse(String providerName, OpenIdTokenResponse tokenResponse, OpenIdClaims openIdClaims, @Nullable State state) {
        // get the current OIDC provider
        Oidc.Provider provider = oidc.getProvider(providerName);

        // get username and groups declared from OIDC system
        String oidcUsername = getUsername(provider, openIdClaims);

        // Some OIDC providers like Keycloak can return a claim with roles and attributes directly,
        // so we don't use the AKHQ internal ClaimProvider mechanism
        if(provider.isUseOidcClaim()){
            return (Flowable.just(createDirectClaimAuthenticationResponse(oidcUsername, openIdClaims)));
        }

        List<String> oidcGroups = getOidcGroups(provider, openIdClaims);

        // Stores the OIDC groups in the JWT token
        // Useful is the AKHQ groups mapping size is more than 4Kb. It saves the OIDC groups and resolves the AKHQ
        // groups for each HTTP request (in the AKHQSecurityRule).
        if (provider.isUseOidcGroupsInToken()) {
            Map<String, Object> attributes = new HashMap<>();
            attributes.put("provider_name", providerName);
            attributes.put("provider_type", ClaimProviderType.OIDC.name());
            attributes.put("groups", oidcGroups);
            return (Flowable.just(
                AuthenticationResponse.success(oidcUsername, List.of(SecurityRule.IS_AUTHENTICATED), attributes)));
        }
        // Stores the AKHQ groups in the JWT token
        // Default behaviour. The OIDC provider gives the groups, AKHQ resolves the groups mapping and saves it in the token.
        else {
            ClaimRequest request = ClaimRequest.builder()
                .providerType(ClaimProviderType.OIDC)
                .providerName(providerName)
                .username(oidcUsername)
                .groups(oidcGroups)
                .build();

            try {
                ClaimResponse claim = claimProvider.generateClaim(request);
                return (Flowable.just(
                    AuthenticationResponse.success(oidcUsername, List.of(SecurityRule.IS_AUTHENTICATED),
                        Map.of("groups", claim.getGroups()))));
            } catch (Exception e) {
                String claimProviderClass = claimProvider.getClass().getName();
                return Flowable.just(new AuthenticationFailed(
                    "Exception from ClaimProvider " + claimProviderClass + ": " + e.getMessage()));
            }
        }
    }

    private AuthenticationResponse createDirectClaimAuthenticationResponse(String oidcUsername, OpenIdClaims openIdClaims) {
        String GROUPS_KEY = "groups";
        if(openIdClaims.contains(GROUPS_KEY) && openIdClaims.get(GROUPS_KEY) instanceof Map){
            return AuthenticationResponse.success(oidcUsername, List.of(SecurityRule.IS_AUTHENTICATED), Map.of("groups", openIdClaims.get(GROUPS_KEY)));
        }

        return new AuthenticationFailed("Exception during Authentication: use-oidc-claim config requires attribute " +
            GROUPS_KEY + " in the OIDC claim");
    }

    /**
     * Tries to read the username from the configured username field.
     *
     * @param provider  The OpenID provider
     * @param openIdClaims  The OpenID claims
     * @return The username to set in the {@link io.micronaut.security.authentication.Authentication}
     */
    protected String getUsername(Oidc.Provider provider, OpenIdClaims openIdClaims) {
        final Object username = getClaimValue(openIdClaims, provider.getUsernameField());
        return Objects.toString(username);
    }

    /**
     * Tries to read groups from the configured groups field.
     * If the configured field cannot be found or isn't some kind of collection or string, it will return an empty set.
     *
     * @param provider     The OpenID provider configuration
     * @param openIdClaims The OpenID claims
     * @return The groups from oidc
     */
    protected List<String> getOidcGroups(Oidc.Provider provider, OpenIdClaims openIdClaims) {
        List<String> groups = new ArrayList<>();
        Object groupsField = getClaimValue(openIdClaims, provider.getGroupsField());
        // When the user belongs to only one group, groupsField can either be an array (with one item)
        // or a string, depending on the IdP implementation.
        if (groupsField instanceof Collection) {
            groups = ((Collection<Object>) groupsField)
                    .stream()
                    .map(Objects::toString)
                    .collect(Collectors.toList());
        } else if (groupsField instanceof String) {
            groups.add((String) groupsField);
        }
        return groups;
    }

    private Object getClaimValue(OpenIdClaims openIdClaims, String name) {
        final String[] subFields = name.split("\\.");
        Object claimValue = openIdClaims.get(subFields[0]);
        for(int i = 1; i < subFields.length; i++) {
            final String subField = subFields[i];
            if (claimValue instanceof Map) {
                claimValue = ((Map) claimValue).get(subField);
            } else {
                break;
            }
        }
        return claimValue;
    }
}
