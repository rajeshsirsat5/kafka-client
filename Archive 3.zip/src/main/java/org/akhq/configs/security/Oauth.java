package org.akhq.configs.security;

import io.micronaut.context.annotation.ConfigurationProperties;
import lombok.Data;
import org.akhq.configs.security.ldap.GroupMapping;
import org.akhq.configs.security.ldap.UserMapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties("akhq.security.oauth2")
@Data
public class Oauth {
    private boolean enabled;
    private Map<String, Provider> providers;

    @Data
    public static class Provider {
        private String label = "Login with OAuth";
        private String usernameField = "login";
        private String groupsField = "organizations_url";
        private String defaultGroup;
        private List<GroupMapping> groups = new ArrayList<>();
        private List<UserMapping> users = new ArrayList<>();
    }

    public Provider getProvider(String key) {
        if (providers == null) {
            providers = new HashMap<>();
        }
        providers.putIfAbsent(key, new Provider());
        return providers.get(key);
    }
}
